import React from 'react';

function Footer() {
    return (
        <footer>
            <div className="center">
                All rights reserved &copy; Sai Snehitha Ravuru
            </div>
        </footer>
    );
}

export default Footer;
